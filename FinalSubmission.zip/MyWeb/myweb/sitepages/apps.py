from django.apps import AppConfig


class SitepagesConfig(AppConfig):
    name = 'sitepages'
