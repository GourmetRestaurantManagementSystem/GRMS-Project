from django import forms
from sitepages.models import Client
from django.core.exceptions import ObjectDoesNotExist

class RegistrationForm(forms.Form):
    name = forms.CharField(label='Name', max_length=50)
    surname = forms.CharField(label='Surname')
    username = forms.CharField(label='Username', max_length=30)
    email = forms.EmailField(label='Email')
    contact_number = forms.CharField(label='Contact Number', max_length=50)
    address = forms.CharField(label='Address')
    password = forms.CharField(label='Password',
                                widget=forms.PasswordInput())
    password2 = forms.CharField(label='Confirm Password',
                                widget=forms.PasswordInput())

    def clean_password2(self):
        if 'password' in self.cleaned_data:
            password = self.cleaned_data['password']
            password2 = self.cleaned_data['password2']
            if password == password2:
                return password2
            raise forms.ValidationError('Passwords do not match')

    def clean_username(self):
        username = self.cleaned_data['username']
        try:
            Client.objects.get(username=username)
        except ObjectDoesNotExist:
            return username
        raise forms.ValidationError('Username taken.')
