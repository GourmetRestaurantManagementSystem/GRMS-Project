from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from sitepages.form import *
from django.contrib import auth

def home(request):
    return render(request, 'sitepages/home.html')

def registration_page(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            client = Client.objects.create(
                name = form.cleaned_data['name'],
                surname = form.cleaned_data['surname'],
                username = form.cleaned_data['username'],
                email = form.cleaned_data['email'],
                contact_number = form.cleaned_data['contact_number'],
                address = form.cleaned_data['address'],
                password = form.cleaned_data['password'])
                
            return render(request, 'sitepages/home.html')
    else:
        form = RegistrationForm()
    variables = RequestContext(request, {'form': form})
    return render_to_response('sitepages/register.html', variables)



    
