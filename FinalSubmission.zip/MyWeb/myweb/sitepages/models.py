from django.db import models

# Create your models here.

class RestaurantManager(models.Model):
    name = models.CharField(max_length = 50)
    surname = models.CharField(max_length = 50)
    password = models.CharField(max_length = 50)
    
class Suppliers(models.Model):
    manager = models.ForeignKey('RestaurantManager')
    name = models.CharField(max_length = 50)
    contact_number = models.CharField(max_length = 50)
    email = models.EmailField(max_length = 50)
    address = models.CharField(max_length = 50)
    stock_quantity = models.IntegerField()
    bulk_price = models.DecimalField(max_digits=10,decimal_places=2)

class Client(models.Model):
    name = models.CharField(max_length = 50)
    surname = models.CharField(max_length = 50)
    username = models.CharField(max_length=30)
    email = models.EmailField(max_length = 50)
    contact_number = models.CharField(max_length = 50)
    address = models.CharField(max_length = 50)
    password = models.CharField(max_length = 50)
    
class MealOptions(models.Model):
    MEAL_TYPE = (('V', 'Vegetarian'),
                 ('H', 'Halaal'),
                 ('S', 'Seafood'),
                 ('C', 'Chinese'),
                 ('N', 'Non-vegetarian')
                 )
    client = models.ForeignKey('Client')
    meal_choice = models.CharField(max_length = 1, choices = MEAL_TYPE)

class Orders(models.Model):
    client = models.ForeignKey('Client')
    date = models.DateField()
    quantity = models.IntegerField()
    total_price = models.DecimalField(max_digits=10,decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True, auto_now=False)

class MenuItem(models.Model):
    order = models.ForeignKey('Orders')
    meal_choice = models.ForeignKey('MealOptions')
    dish_name = models.CharField(max_length = 50)
    ingredients = models.CharField(max_length = 500)
    dish_price = models.DecimalField(max_digits=10,decimal_places=2)
    
class ModifiedOrders(models.Model):
    menu_item = models.ForeignKey('MenuItem')
    order = models.ForeignKey('Orders')
    added_ingredients = models.CharField(max_length = 200)
    removed_ingredients = models.CharField(max_length = 200)
    deducted_amount = models.DecimalField(max_digits=10,decimal_places=2)
    added_amount = models.DecimalField(max_digits=10,decimal_places=2)

class Stock(models.Model):
    supplier = models.ForeignKey('Suppliers')
    menu_item = models.ForeignKey('MenuItem')
    quantity = models.IntegerField()
    total_price = models.DecimalField(max_digits=10,decimal_places=2)

class Reservations(models.Model):
    reservation_date = models.DateField()
    client = models.ForeignKey('Client')
    restaurant_manager = models.ForeignKey('RestaurantManager')
    paid = models.BooleanField(default = False)
    cancellation_date = models.DateField()
    confirmation_date = models.DateField()
    table_count = models.IntegerField()

class Invoice(models.Model):
    client = models.ForeignKey('Client')
    order = models.ForeignKey('Orders')
    payment = models.ForeignKey('ModeOfPayment')
    date_of_invoice = models.DateField()
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

class ModeOfPayment(models.Model):
    client = models.ForeignKey('Client')
    PAYMENT_TYPE = (('CA', 'Cash'),
                 ('CC', 'Credit Card'),
                 ('CQ', 'Cheque'),
                 )
    payment_mode = models.CharField(max_length = 2, choices = PAYMENT_TYPE)
    
    
  
    
















    
    
